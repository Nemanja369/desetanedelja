const Register = () => {
    return ( <div>REGISTER</div> );
}
 
export default Register;