import { useState } from "react";
import { Link,useHistory } from "react-router-dom";

const Login = ({setUser}) => {
    const [username,setUsername] = useState('')
    const [password,setPassword] = useState('')

    const history = useHistory()
    console.log(history);

    return ( 
        <>
            <form onSubmit={(e)=>{
                e.preventDefault()
                setUser({username,password})
                history.push('/quotes')
            }}>
                <input type="text"  placeholder="Username/Email..." onChange={(e)=>{setUsername(e.target.value)}}/>
                <input type="password" placeholder="Password..." onChange={(e)=>{setPassword(e.target.value)}} />
                <input type="submit" value="LogIn" />
            </form>
            <div>
                <Link to="/register">Not registred?</Link>
            </div>
        </>
     );
}
 
export default Login;