const CreateQuote = () => {
    return ( <div>CREATE QUOTE</div> );
}
 
export default CreateQuote;