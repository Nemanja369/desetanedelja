const Quotes = () => {
    return ( <div>QUOTES</div> );
}
 
export default Quotes;